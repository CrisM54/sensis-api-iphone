
#import <Foundation/Foundation.h>

NSString* urlEncode(NSString *url);