

@interface LoadingView : UIView 
{

}

@end
